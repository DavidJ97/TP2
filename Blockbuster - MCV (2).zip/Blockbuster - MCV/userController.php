<?php
require_once('class/CRUD.php');
require 'userModel.php';

class UserController {
    private $crud;
    private $userModel;

    public function __construct() {
        $this->crud = new CRUD;
        $this->userModel = new UserModel();
    }

    public function displayUsers() {
        $users = $this->crud->select('utilisateurs');
        require 'userView.php';
    }

    public function addUserForm() {
        require 'userView.php';
    }

   public function addUser() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  
        $data = array(
            'nom' => $_POST['nom'],
            'prenom' => $_POST['prenom'],
            'email' => $_POST['email'],
            'mot_de_passe' => password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT),
            'est_admin' => isset($_POST['est_admin']) ? 1 : 0,
        );

     
        $this->userModel->insertUser($data);

       
        header('Location: user-show.php');
        exit;
    }
}


    public function closeConnection() {
        $this->crud = null;
    }
}
?>
