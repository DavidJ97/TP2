Pour rentrer sur PhpMyadmin
utilisateur : e1491175
Mot de passe treGU10TF428xeBbSmAB

le dossier se trouve sur 
https://e1491175.webdev.cmaisonneuve.qc.ca/Blockbuster/

Github
https://github.com/DavidJ97/blockbuster.git
