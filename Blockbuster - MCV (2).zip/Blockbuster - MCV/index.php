<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blockbuster</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<img src="images/blockbuster-logo.png" alt="Blockbuster Logo" width="220" height="120">
  
</div>
<?php
require_once 'vendor/autoload.php';

// Initialisation de Twig
$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);

require 'filmController.php';
require 'userController.php';

$film_controller = new FilmController();
$user_controller = new UserController();

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'add':
        $film_controller->addDvd();
        break;
    case 'add_form':
        $film_controller->addDvdForm();
        break;
    case 'dvd_details':
        $film_controller->displayDvdDetails();
        break;
    case 'delete_dvd':
        $film_controller->deleteDvd();
        break;
    case 'edit_dvd':
        $film_controller->editDvd();
        break;
    case 'add_user':
        $user_controller->addUser();
        break;
    case 'add_user_form':
        $user_controller->addUserForm();
        break;
    default:
        $film_controller->displayFilms();
}

$film_controller->closeConnection();
?>

