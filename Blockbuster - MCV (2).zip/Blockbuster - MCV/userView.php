<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Ajouter un utilisateur</title>
</head>
<body>
    <form action="index.php?action=add_user" method="post">
        <h1>Ajouter un utilisateur</h1>
        <label>Nom
            <input type="text" name="nom" required>
        </label>
        <label>Prénom
            <input type="text" name="prenom" required>
        </label>
        <label>Email
            <input type="email" name="email" required>
        </label>
        <label>Mot de passe
            <input type="password" name="mot_de_passe" required>
        </label>
        <label>Est administrateur ?
            <input type="checkbox" name="est_admin">
        </label>
        <input type="submit" value="Enregistrer">
    </form>
    <a href="index.php">Retour à l'index</a>
</body>
</html>
