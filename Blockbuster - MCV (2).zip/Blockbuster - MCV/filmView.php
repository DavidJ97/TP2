<!DOCTYPE html>
<html>
<head>
    <title>Liste de Films</title>
</head>
<body>
    <div class="btn-container">
    	<a href="index.php?action=add_form" class="btn">Add DVD</a>
    	<a href="index.php?action=add_user_form" class="btn">Ajouter un utilisateur</a>
    </div>
    <table>
        <th>Titre</th>
        <th>Année</th>
        <th>Genre</th>
        <th>Réalisateur</th>
        <th>Durée</th>
        <th>Description</th>
        <th>Images</th>

        <?php foreach ($films as $row): ?>
            <tr>
                <td><a href="index.php?action=dvd_details&id=<?= $row['id'] ?>"><?= $row['titre']?></a></td>
                <td><?= $row['annee']?></td>
                <td><?= $row['genre']?></td>
                <td><?= $row['realisateur']?></td>
                <td><?= $row['duree']?> min</td>
                <td><?= $row['description']?></td>
                <td><img src="images/<?= $row['image']?>" alt="<?= $row['titre']?>" style="width: 100px;"></td>
            </tr>
        <?php endforeach; ?>

    </table>
</body>
</html>
