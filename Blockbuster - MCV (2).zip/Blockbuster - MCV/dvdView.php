<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Ajouter un DVD</title>
</head>
<body>
    <form action="index.php?action=add" method="post">
        <h1>Ajouter un DVD</h1>
        <label>Titre
            <input type="text" name="titre" required>
        </label>
        <label>Année
            <input type="text" name="annee" required>
        </label>
        <label>Genre
            <input type="text" name="genre" required>
        </label>
        <label>Réalisateur
            <input type="text" name="realisateur" required>
        </label>
        <label>Description
            <input type="text" name="description" required>
        </label>
        <label>Durée
            <input type="text" name="duree" required>
        </label>
        <input type="submit" value="Enregistrer">
    </form>
    <a href="index.php">Retour à l'index</a>
</body>
</html>
