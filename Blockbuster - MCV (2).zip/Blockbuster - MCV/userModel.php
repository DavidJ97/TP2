<?php
require_once('class/CRUD.php');

class UserModel {
    private $crud;

    public function __construct() {
        $this->crud = new CRUD;
    }

    public function insertUser($data) {
        return $this->crud->insert('utilisateurs', $data);
    }
}
?>
