<?php
require_once('class/CRUD.php');

class DvdModel {
    private $crud;

    public function __construct() {
        $this->crud = new CRUD;
    }

    public function insertDvd($data) {
        return $this->crud->insert('films', $data);
    }
    
    public function deleteDvd($id) {
        $sql = "DELETE FROM films WHERE id = :id";
        $stmt = $this->crud->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    }
}
?>
