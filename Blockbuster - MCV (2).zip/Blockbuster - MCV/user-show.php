<?php

if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('class/CRUD.php');
    $crud = new CRUD;
    $Utilisateurs = $crud->selectId('Utilisateurs', $id);

    extract($Utilisateurs);
}else{
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Utilisateur</title>
</head>
<body>
    <h1>Utilisateur</h1>
    <table border="1">
        <tr>
            <th>Nom</th>
            <td><?= $nom; ?></td>
        </tr>
        <tr>
            <th>Prénom</th>
            <td><?= $prenom; ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?= $email; ?></td>
        </tr>
        <tr>
            <th>Est admin</th>
            <td><?= ($est_admin ? 'Oui' : 'Non'); ?></td>
        </tr>
    </table>
    <a href="user-edit.php?id=<?= $id; ?>">Modifier</a>
    <form action="user-delete.php" method="post" style="margin-top: 20px;">
        <input type="hidden" name="id" value="<?= $id; ?>">
        <input type="submit" value="Supprimer">
    </form>
</body>

    <a href="index.php">retour à l'index </a> <!-- Lien pour accéder à la page show-user.php -->
</body>
</html>
