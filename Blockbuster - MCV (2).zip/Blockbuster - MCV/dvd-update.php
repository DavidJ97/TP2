<<?php
require_once('class/CRUD.php');
$crud = new CRUD;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id'])) {
        // Récupérer l'ID du DVD depuis le formulaire
        $id = $_POST['id'];

        // Récupérer les détails existants du DVD de la base de données
        $film = $crud->selectId('Films', $id);

        if ($film) {
            // Mettre à jour les détails du DVD avec les valeurs issues du formulaire
            $titre = $_POST['titre'];
            $annee = $_POST['annee'];
            $genre = $_POST['genre'];
            $realisateur = $_POST['realisateur'];
            $description = $_POST['description'];
            $duree = $_POST['duree'];
            $image = $_POST['image'];

            // Mettre à jour les détails du DVD dans la base de données
            $data = array(
                'id' => $id,
                'titre' => $titre,
                'annee' => $annee,
                'genre' => $genre,
                'realisateur' => $realisateur,
                'description' => $description,
                'duree' => $duree,
                'image' => $image
            );

            $crud->update('Films', $data, 'id', $id);

            // Rediriger vers la page de détails du DVD ou une autre page appropriée
            header("Location: index.php");
        } else {
            // Gérer le cas où le DVD n'existe pas
            echo "DVD non trouvé.";
        }
    } else {
        // Gérer le cas où l'ID n'est pas fourni dans le formulaire
        echo "ID du DVD manquant.";
    }
} else {
    // Gérer les cas où le formulaire n'est pas soumis via POST
    echo "Requête invalide.";
}
?>
